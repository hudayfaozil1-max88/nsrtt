const fs = require("fs");
const path = require("path");
const { DatabaseSync } = require("node:sqlite");

const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "deen-ledger.db"));
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    avatar TEXT,
    language TEXT NOT NULL DEFAULT 'en',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS people (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('deen', 'iowe')),
    amount REAL NOT NULL DEFAULT 0,
    date TEXT NOT NULL,
    is_starred INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL CHECK(action IN ('add', 'pay')),
    amount REAL NOT NULL,
    date_time TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (person_id) REFERENCES people(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

function personRowToClient(row, history = []) {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    amount: Number(row.amount).toFixed(2),
    date: row.date,
    isStarred: Boolean(row.is_starred),
    history: history.map((h) => ({
      action: h.action,
      amount: Number(h.amount).toFixed(2),
      dateTime: h.date_time
    }))
  };
}

function getHistoryForPerson(personId, userId) {
  return db
    .prepare(
      `SELECT action, amount, date_time
       FROM history
       WHERE person_id = ? AND user_id = ?
       ORDER BY id DESC`
    )
    .all(personId, userId);
}

function getPeopleForUser(userId) {
  const rows = db
    .prepare(
      `SELECT * FROM people WHERE user_id = ? ORDER BY datetime(created_at) DESC, id DESC`
    )
    .all(userId);
  return rows.map((row) => personRowToClient(row, getHistoryForPerson(row.id, userId)));
}

function getPersonForUser(personId, userId) {
  const row = db
    .prepare(`SELECT * FROM people WHERE id = ? AND user_id = ?`)
    .get(personId, userId);
  if (!row) return null;
  return personRowToClient(row, getHistoryForPerson(row.id, userId));
}

module.exports = {
  db,
  getPeopleForUser,
  getPersonForUser,
  personRowToClient,
  getHistoryForPerson
};
