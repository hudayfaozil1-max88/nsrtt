require("dotenv").config();

const fs = require("fs");
const path = require("path");
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const { db, getPeopleForUser, getPersonForUser } = require("./db");

const PORT = Number(process.env.PORT) || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "deen-ledger-dev-secret-change-me";
const uploadsDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadsDir, { recursive: true });

const app = express();
app.use(express.json({ limit: "4mb" }));
app.use("/uploads", express.static(uploadsDir));
app.use(express.static(path.join(__dirname, "..", "public")));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase() || ".jpg";
    cb(null, `user-${req.user.id}-${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 3 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("Only image files are allowed"));
    }
    cb(null, true);
  }
});

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: "30d" });
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: "Please log in." });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare("SELECT id, name, email, avatar, language FROM users WHERE id = ?").get(payload.id);
    if (!user) {
      return res.status(401).json({ error: "Account not found." });
    }
    req.user = user;
    next();
  } catch (_err) {
    return res.status(401).json({ error: "Session expired. Please log in again." });
  }
}

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    avatar: user.avatar,
    language: user.language
  };
}

function nowStamp() {
  const today = new Date();
  const dateStr = today.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const timeStr = today.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
  return { dateStr, fullDateTime: `${dateStr} - ${timeStr}` };
}

app.post("/api/auth/signup", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (!name || !email || password.length < 4) {
    return res.status(400).json({ error: "Name, email/phone, and a password of at least 4 characters are required." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    return res.status(409).json({ error: "An account with this email or phone already exists." });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)")
    .run(name, email, passwordHash);
  const user = db.prepare("SELECT id, name, email, avatar, language FROM users WHERE id = ?").get(info.lastInsertRowid);
  return res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid email/phone or password." });
  }
  return res.json({ token: signToken(user), user: publicUser(user) });
});

app.get("/api/auth/me", authRequired, (req, res) => {
  res.json({ user: publicUser(req.user) });
});

app.put("/api/profile", authRequired, (req, res) => {
  const language = req.body.language === "so" ? "so" : req.body.language === "en" ? "en" : req.user.language;
  db.prepare("UPDATE users SET language = ? WHERE id = ?").run(language, req.user.id);
  const user = db.prepare("SELECT id, name, email, avatar, language FROM users WHERE id = ?").get(req.user.id);
  res.json({ user: publicUser(user) });
});

app.post("/api/profile/avatar", authRequired, (req, res) => {
  upload.single("avatar")(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || "Could not upload image." });
    }
    if (!req.file) {
      return res.status(400).json({ error: "No image selected." });
    }
    const avatarPath = `/uploads/${req.file.filename}`;
    db.prepare("UPDATE users SET avatar = ? WHERE id = ?").run(avatarPath, req.user.id);
    const user = db.prepare("SELECT id, name, email, avatar, language FROM users WHERE id = ?").get(req.user.id);
    res.json({ user: publicUser(user) });
  });
});

app.get("/api/people", authRequired, (req, res) => {
  res.json({ people: getPeopleForUser(req.user.id) });
});

app.post("/api/people", authRequired, (req, res) => {
  const name = String(req.body.name || "").trim();
  const type = req.body.type === "iowe" ? "iowe" : req.body.type === "deen" ? "deen" : null;
  const numAmount = Number(req.body.amount);

  if (!name || !type || !Number.isFinite(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: "Person name, type, and a valid amount are required." });
  }

  const { dateStr, fullDateTime } = nowStamp();
  const existing = db
    .prepare("SELECT * FROM people WHERE user_id = ? AND lower(name) = lower(?)")
    .get(req.user.id, name);

  const insertHistory = db.prepare(
    "INSERT INTO history (person_id, user_id, action, amount, date_time) VALUES (?, ?, 'add', ?, ?)"
  );

  if (existing) {
    const nextAmount = Number(existing.amount) + numAmount;
    db.prepare("UPDATE people SET type = ?, amount = ? WHERE id = ? AND user_id = ?").run(
      type,
      nextAmount,
      existing.id,
      req.user.id
    );
    insertHistory.run(existing.id, req.user.id, numAmount, fullDateTime);
  } else {
    const info = db
      .prepare("INSERT INTO people (user_id, name, type, amount, date, is_starred) VALUES (?, ?, ?, ?, ?, 0)")
      .run(req.user.id, name, type, numAmount, dateStr);
    insertHistory.run(info.lastInsertRowid, req.user.id, numAmount, fullDateTime);
  }

  res.status(201).json({ people: getPeopleForUser(req.user.id) });
});

app.patch("/api/people/:id/star", authRequired, (req, res) => {
  const person = getPersonForUser(Number(req.params.id), req.user.id);
  if (!person) {
    return res.status(404).json({ error: "Person not found." });
  }
  const next = person.isStarred ? 0 : 1;
  db.prepare("UPDATE people SET is_starred = ? WHERE id = ? AND user_id = ?").run(next, person.id, req.user.id);
  res.json({ people: getPeopleForUser(req.user.id) });
});

app.post("/api/people/:id/actions", authRequired, (req, res) => {
  const personRow = db
    .prepare("SELECT * FROM people WHERE id = ? AND user_id = ?")
    .get(Number(req.params.id), req.user.id);
  if (!personRow) {
    return res.status(404).json({ error: "Person not found." });
  }

  const action = req.body.action === "pay" ? "pay" : req.body.action === "add" ? "add" : null;
  const numAmount = Number(req.body.amount);
  if (!action || !Number.isFinite(numAmount) || numAmount <= 0) {
    return res.status(400).json({ error: "A valid action and amount are required." });
  }

  let currentAmt = Number(personRow.amount);
  if (action === "add") {
    currentAmt += numAmount;
  } else {
    currentAmt -= numAmount;
    if (currentAmt < 0) currentAmt = 0;
  }

  const { fullDateTime } = nowStamp();
  db.prepare("UPDATE people SET amount = ? WHERE id = ? AND user_id = ?").run(currentAmt, personRow.id, req.user.id);
  db.prepare("INSERT INTO history (person_id, user_id, action, amount, date_time) VALUES (?, ?, ?, ?, ?)").run(
    personRow.id,
    req.user.id,
    action,
    numAmount,
    fullDateTime
  );

  res.json({
    person: getPersonForUser(personRow.id, req.user.id),
    people: getPeopleForUser(req.user.id)
  });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

app.listen(PORT, () => {
  process.stdout.write(`Deen Ledger running at http://localhost:${PORT}\n`);
});
