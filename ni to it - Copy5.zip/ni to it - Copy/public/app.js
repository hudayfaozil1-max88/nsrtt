const TOKEN_KEY = "deen_ledger_token";

const translations = {
  en: {
    welcome_title: "Welcome to Deen Ledger",
    welcome_sub: "Please log in to your account to continue",
    signup_title: "Create New Account",
    signup_sub: "Join Deen Ledger today",
    lbl_fullname: "Full Name",
    lbl_email: "Email or Phone",
    lbl_password: "Password",
    btn_login: "Log In",
    btn_signup: "Sign Up",
    no_account: "Don't have an account?",
    have_account: "Already have an account?",
    btn_signup_toggle: "Sign Up now",
    btn_login_toggle: "Log In here",
    ph_search: "Search person, amount...",
    tab_all: "All",
    tab_deen: "Deen",
    tab_iowe: "I Owe",
    empty_home_title: "No starred people yet",
    empty_home_desc: "Go to 'People', tap the star icon next to a person to pin them to Home.",
    empty_contacts_title: "No contacts found",
    empty_contacts_desc: "Tap (+) to add a new person & amount.",
    empty_paid_title: "No transactions recorded yet",
    empty_paid_desc: "All activity across all people will show up here.",
    set_language: "Language",
    set_security: "Security & PIN Code",
    set_security_sub: "Lock application",
    btn_logout: "Log Out",
    set_logout_sub: "Sign out of your account",
    modal_add_title: "Add New Person / Debt",
    lbl_person_name: "Person Name",
    lbl_trans_type: "Type",
    lbl_amount: "Amount ($)",
    btn_save: "Save",
    history_title: "Transaction History"
  },
  so: {
    welcome_title: "Kusoo Dhowaw Deen Ledger",
    welcome_sub: "Fadlan gal akowntigaaga si aad u sii wadato",
    signup_title: "Samayso Akaunti Cusub",
    signup_sub: "Kusoo biir Deen Ledger maanta",
    lbl_fullname: "Magacaaaga Buuxa",
    lbl_email: "Email ama Taleefan",
    lbl_password: "Password (Furaha)",
    btn_login: "Log In",
    btn_signup: "Sign Up",
    no_account: "Akaunti ma leehid?",
    have_account: "Akaunti waad leedahay?",
    btn_signup_toggle: "Sign Up samayso",
    btn_login_toggle: "Log In gal",
    ph_search: "Search person, amount...",
    tab_all: "All",
    tab_deen: "Deen",
    tab_iowe: "I Owe",
    empty_home_title: "Macaamiil xiddig leh ma jiraan",
    empty_home_desc: "Aad Tab-ka 'People', taabo xiddigta qofka si uu ugu soo muuqdo Home-ka.",
    empty_contacts_title: "Macaamiil ma jiraan",
    empty_contacts_desc: "Taabo (+) si aad macmiil & lacag cusub u kordhiso.",
    empty_paid_title: "Warbixin maamul ma jirto",
    empty_paid_desc: "Dhamaan dhaqdhaqaaqa lacagaha halkan ayay ku soo bixi doonaan.",
    set_language: "Luuqadda (Language)",
    set_security: "Amniga & PIN Code",
    set_security_sub: "Xidhida App-ka",
    btn_logout: "Log Out",
    set_logout_sub: "Ka bax akowntiga",
    modal_add_title: "Kudhar Person / Deen Cusub",
    lbl_person_name: "Magaca Qofka",
    lbl_trans_type: "Nooca",
    lbl_amount: "Qaddarka ($)",
    btn_save: "Kaydi",
    history_title: "Taariikhda Lacagaha (History)"
  }
};

let currentLang = "en";
let peopleData = [];
let activePersonId = null;
let quickActionType = "add";
let cardState = "deen";
let peopleTabFilter = "all";

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData) && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(`/api${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || "Request failed");
  }
  return data;
}

function setLanguage(lang) {
  currentLang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (translations[lang][key]) el.textContent = translations[lang][key];
  });
  document.querySelectorAll("[data-i18n-ph]").forEach((el) => {
    const key = el.getAttribute("data-i18n-ph");
    if (translations[lang][key]) el.placeholder = translations[lang][key];
  });
  document.getElementById("currentLangDisplay").textContent = lang === "so" ? "Soomaali" : "English";
  syncLangChecks();
}

function syncLangChecks() {
  const optSomali = document.getElementById("optSomali");
  const optEnglish = document.getElementById("optEnglish");
  const somaliSelected = currentLang === "so";
  optSomali.classList.toggle("selected", somaliSelected);
  optEnglish.classList.toggle("selected", !somaliSelected);
  optSomali.querySelector(".fa-check").style.display = somaliSelected ? "inline-block" : "none";
  optEnglish.querySelector(".fa-check").style.display = somaliSelected ? "none" : "inline-block";
}

function applyUser(user) {
  displayName.textContent = user.name || "User Account";
  displayEmail.textContent = user.email;
  if (user.language) setLanguage(user.language);
  if (user.avatar) {
    profileAvatar.innerHTML = `<img src="${escapeHtml(user.avatar)}" style="width:100%; height:100%; border-radius:50%; object-fit:cover;">`;
  } else {
    profileAvatar.innerHTML = `<i class="fa-solid fa-user"></i>`;
  }
}

async function loadPeople() {
  const data = await api("/people");
  peopleData = data.people || [];
  renderHomeView();
  renderPeopleView(peopleTabFilter);
  renderAllTransactionsView();
  updateTotals();
}

function enterApp(user) {
  applyUser(user);
  authScreen.style.display = "none";
  appScreen.style.display = "flex";
  activateNav("home");
  loadPeople().catch((err) => alert(err.message));
}

function leaveApp() {
  clearToken();
  peopleData = [];
  appScreen.style.display = "none";
  authScreen.style.display = "flex";
  personDetailOverlay.classList.remove("active");
}

const authScreen = document.getElementById("authScreen");
const appScreen = document.getElementById("appScreen");
const authForm = document.getElementById("authForm");
const authTitle = document.getElementById("authTitle");
const authSubtitle = document.getElementById("authSubtitle");
const authSubmitBtn = document.getElementById("authSubmitBtn");
const nameGroup = document.getElementById("nameGroup");
const authToggleBtn = document.getElementById("authToggleBtn");
const authToggleText = document.getElementById("authToggleText");
const logoutBtn = document.getElementById("logoutBtn");
const displayName = document.getElementById("displayName");
const displayEmail = document.getElementById("displayEmail");
let isSignUp = false;

authToggleBtn.addEventListener("click", () => {
  isSignUp = !isSignUp;
  if (isSignUp) {
    authTitle.textContent = translations[currentLang].signup_title;
    authSubtitle.textContent = translations[currentLang].signup_sub;
    authSubmitBtn.textContent = translations[currentLang].btn_signup;
    nameGroup.style.display = "block";
    authToggleText.textContent = translations[currentLang].have_account;
    authToggleBtn.textContent = translations[currentLang].btn_login_toggle;
  } else {
    authTitle.textContent = translations[currentLang].welcome_title;
    authSubtitle.textContent = translations[currentLang].welcome_sub;
    authSubmitBtn.textContent = translations[currentLang].btn_login;
    nameGroup.style.display = "none";
    authToggleText.textContent = translations[currentLang].no_account;
    authToggleBtn.textContent = translations[currentLang].btn_signup_toggle;
  }
});

authForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const emailVal = document.getElementById("authEmail").value;
  const passwordVal = document.getElementById("authPassword").value;
  const nameVal = document.getElementById("authName").value || "User";
  try {
    const path = isSignUp ? "/auth/signup" : "/auth/login";
    const body = isSignUp
      ? { name: nameVal, email: emailVal, password: passwordVal }
      : { email: emailVal, password: passwordVal };
    const data = await api(path, { method: "POST", body: JSON.stringify(body) });
    setToken(data.token);
    enterApp(data.user);
  } catch (err) {
    alert(err.message);
  }
});

logoutBtn.addEventListener("click", () => {
  leaveApp();
});

const avatarInput = document.getElementById("avatarInput");
const profileAvatar = document.getElementById("profileAvatar");
avatarInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append("avatar", file);
  try {
    const data = await api("/profile/avatar", { method: "POST", body: formData });
    applyUser(data.user);
  } catch (err) {
    alert(err.message);
  }
});

const langSettingBtn = document.getElementById("langSettingBtn");
const langModalOverlay = document.getElementById("langModalOverlay");
const closeLangModalBtn = document.getElementById("closeLangModalBtn");
const optSomali = document.getElementById("optSomali");
const optEnglish = document.getElementById("optEnglish");
langSettingBtn.addEventListener("click", () => langModalOverlay.classList.add("active"));
closeLangModalBtn.addEventListener("click", () => langModalOverlay.classList.remove("active"));
optSomali.addEventListener("click", async () => {
  setLanguage("so");
  langModalOverlay.classList.remove("active");
  try {
    await api("/profile", { method: "PUT", body: JSON.stringify({ language: "so" }) });
  } catch (_err) {
    /* keep UI language even if save fails */
  }
});
optEnglish.addEventListener("click", async () => {
  setLanguage("en");
  langModalOverlay.classList.remove("active");
  try {
    await api("/profile", { method: "PUT", body: JSON.stringify({ language: "en" }) });
  } catch (_err) {
    /* keep UI language even if save fails */
  }
});

const homeTotalCard = document.getElementById("homeTotalCard");
const homeView = document.getElementById("homeView");
const peopleView = document.getElementById("peopleView");
const reportsView = document.getElementById("reportsView");
const profileView = document.getElementById("profileView");
const navHome = document.getElementById("navHome");
const navPeople = document.getElementById("navPeople");
const navDocs = document.getElementById("navDocs");
const navProfile = document.getElementById("navProfile");
const navItems = document.querySelectorAll(".bottom-nav .nav-item");

function hideAllViews() {
  homeView.classList.remove("active");
  peopleView.classList.remove("active");
  reportsView.classList.remove("active");
  profileView.classList.remove("active");
}

function activateNav(viewName) {
  navItems.forEach((n) => n.classList.remove("active"));
  hideAllViews();
  if (viewName === "home") {
    homeTotalCard.style.display = "flex";
    homeView.classList.add("active");
    navHome.classList.add("active");
    renderHomeView();
    updateTotals();
  } else {
    homeTotalCard.style.display = "none";
    if (viewName === "people") {
      peopleView.classList.add("active");
      navPeople.classList.add("active");
      renderPeopleView(peopleTabFilter);
    } else if (viewName === "reports") {
      reportsView.classList.add("active");
      navDocs.classList.add("active");
      renderAllTransactionsView();
    } else if (viewName === "profile") {
      profileView.classList.add("active");
      navProfile.classList.add("active");
    }
  }
}

navHome.addEventListener("click", () => activateNav("home"));
navPeople.addEventListener("click", () => activateNav("people"));
navDocs.addEventListener("click", () => activateNav("reports"));
navProfile.addEventListener("click", () => activateNav("profile"));

const cardBadgeTitle = document.getElementById("cardBadgeTitle");
const totalAmountDisplay = document.getElementById("totalAmountDisplay");
const cardDescLabel = document.getElementById("cardDescLabel");
homeTotalCard.addEventListener("click", () => {
  cardState = cardState === "deen" ? "iowe" : "deen";
  updateTotals();
});

function updateTotals() {
  let totalDeen = 0;
  let totalIOwe = 0;
  peopleData.forEach((p) => {
    const amt = parseFloat(p.amount) || 0;
    if (p.type === "deen") {
      totalDeen += amt;
    } else if (p.type === "iowe") {
      totalIOwe += amt;
    }
  });
  if (cardState === "deen") {
    cardBadgeTitle.textContent = "Total : Deen";
    totalAmountDisplay.textContent = `$ ${totalDeen.toFixed(2)}`;
    cardDescLabel.textContent = "Borrowed from others (Tap to switch)";
  } else {
    cardBadgeTitle.textContent = "Total : I Owe";
    totalAmountDisplay.textContent = `$ ${totalIOwe.toFixed(2)}`;
    cardDescLabel.textContent = "Total owed to you by others (Tap to switch)";
  }
}

const peopleTabs = document.querySelectorAll("[data-people-tab]");
peopleTabs.forEach((btn) => {
  btn.addEventListener("click", () => {
    peopleTabs.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    peopleTabFilter = btn.dataset.peopleTab;
    renderPeopleView(peopleTabFilter);
  });
});

function renderPeopleView(filterType = "all") {
  const peopleList = document.getElementById("peopleList");
  const emptyPeople = document.getElementById("emptyPeople");
  peopleList.innerHTML = "";
  const filtered = peopleData.filter((p) => filterType === "all" || p.type === filterType);
  if (filtered.length === 0) {
    emptyPeople.style.display = "block";
  } else {
    emptyPeople.style.display = "none";
    filtered.forEach((p) => {
      peopleList.appendChild(createPeopleCard(p));
    });
  }
}

function renderHomeView() {
  const starredList = document.getElementById("starredList");
  const emptyHome = document.getElementById("emptyHome");
  starredList.innerHTML = "";
  const starred = peopleData.filter((p) => p.isStarred);
  if (starred.length === 0) {
    emptyHome.style.display = "block";
  } else {
    emptyHome.style.display = "none";
    starred.forEach((p) => {
      starredList.appendChild(createPeopleCard(p));
    });
  }
}

function renderAllTransactionsView() {
  const allTransactionsList = document.getElementById("allTransactionsList");
  const emptyAllTrans = document.getElementById("emptyAllTrans");
  allTransactionsList.innerHTML = "";
  const allHistory = [];
  peopleData.forEach((p) => {
    if (p.history) {
      p.history.forEach((h) => {
        allHistory.push({
          personName: p.name,
          personType: p.type,
          action: h.action,
          amount: h.amount,
          dateTime: h.dateTime
        });
      });
    }
  });
  if (allHistory.length === 0) {
    emptyAllTrans.style.display = "block";
  } else {
    emptyAllTrans.style.display = "none";
    allHistory.forEach((h) => {
      const item = document.createElement("div");
      item.className = "history-item";
      const isDeen = h.personType === "deen";
      const isAdd = h.action === "add";
      let titleText = "";
      let color = "";
      let prefix = "";
      if (isAdd) {
        if (isDeen) {
          color = "#b91c1c";
          titleText = "DEEN ADDED (+)";
          prefix = "+";
        } else {
          color = "#d97706";
          titleText = "I OWE ADDED (+)";
          prefix = "+";
        }
      } else {
        color = "#047857";
        titleText = isDeen ? "DEEN SETTLED (-)" : "I OWE RECEIVED (-)";
        prefix = "-";
      }
      item.innerHTML = `
        <div class="history-info">
          <div class="hist-person">${escapeHtml(h.personName)}</div>
          <div class="hist-type" style="color: ${color};">${titleText}</div>
          <div class="hist-date"><i class="fa-regular fa-clock"></i> ${escapeHtml(h.dateTime)}</div>
        </div>
        <div class="history-amount" style="color: ${color};">${prefix}$ ${escapeHtml(h.amount)}</div>
      `;
      allTransactionsList.appendChild(item);
    });
  }
}

function createPeopleCard(p) {
  const isDeen = p.type === "deen";
  const badgeClass = isDeen ? "deen" : "iowe";
  const badgeText = isDeen ? "DEEN" : "I OWE";
  const subText = isDeen ? "You borrowed from them" : "They borrowed from you";
  const card = document.createElement("div");
  card.className = "transaction-item";
  card.innerHTML = `
    <div class="user-info">
      <i class="fa-solid fa-star star-btn ${p.isStarred ? "active" : ""}"></i>
      <div class="avatar avatar-purple"><i class="fa-solid fa-user"></i></div>
      <div class="details">
        <div class="name">${escapeHtml(p.name)}</div>
        <div class="subtext">${subText}</div>
        <div class="date"><i class="fa-regular fa-calendar"></i> ${escapeHtml(p.date)}</div>
      </div>
    </div>
    <div class="amount-info">
      <div class="amount" style="color: ${isDeen ? "#b91c1c" : "#d97706"};">$ ${escapeHtml(p.amount)}</div>
      <span class="status-badge ${badgeClass}"><span class="dot ${badgeClass}"></span> ${badgeText}</span>
    </div>
  `;
  card.addEventListener("click", async (e) => {
    if (e.target.classList.contains("star-btn")) {
      try {
        const data = await api(`/people/${p.id}/star`, { method: "PATCH" });
        peopleData = data.people || [];
        renderPeopleView(peopleTabFilter);
        renderHomeView();
      } catch (err) {
        alert(err.message);
      }
      return;
    }
    openPersonDetail(p);
  });
  return card;
}

const personDetailOverlay = document.getElementById("personDetailOverlay");
const closeDetailBtn = document.getElementById("closeDetailBtn");
const detailTotalAmount = document.getElementById("detailTotalAmount");
const detailPersonName = document.getElementById("detailPersonName");
const detailHistoryList = document.getElementById("detailHistoryList");
const btnDetailAdd = document.getElementById("btnDetailAdd");
const btnDetailPay = document.getElementById("btnDetailPay");

function openPersonDetail(p) {
  activePersonId = p.id;
  detailPersonName.textContent = p.name;
  detailTotalAmount.textContent = `$ ${parseFloat(p.amount).toFixed(2)}`;
  renderHistory(p);
  personDetailOverlay.classList.add("active");
}

function renderHistory(p) {
  detailHistoryList.innerHTML = "";
  if (!p.history || p.history.length === 0) {
    detailHistoryList.innerHTML = `<div style="text-align:center; color:#9ca3af; font-size:13px; padding:20px;">No history recorded yet.</div>`;
    return;
  }
  const isDeen = p.type === "deen";
  p.history.forEach((h) => {
    const item = document.createElement("div");
    item.className = "history-item";
    const isAdd = h.action === "add";
    let titleText = "";
    let color = "";
    let prefix = "";
    if (isAdd) {
      if (isDeen) {
        color = "#b91c1c";
        titleText = "DEEN ADDED (+)";
        prefix = "+";
      } else {
        color = "#d97706";
        titleText = "I OWE ADDED (+)";
        prefix = "+";
      }
    } else {
      color = "#047857";
      titleText = isDeen ? "DEEN SETTLED (-)" : "I OWE RECEIVED (-)";
      prefix = "-";
    }
    item.innerHTML = `
      <div class="history-info">
        <div class="hist-type" style="color: ${color};">${titleText}</div>
        <div class="hist-date"><i class="fa-regular fa-clock"></i> ${escapeHtml(h.dateTime)}</div>
      </div>
      <div class="history-amount" style="color: ${color};">${prefix}$ ${escapeHtml(h.amount)}</div>
    `;
    detailHistoryList.appendChild(item);
  });
}

closeDetailBtn.addEventListener("click", () => personDetailOverlay.classList.remove("active"));

const quickModalOverlay = document.getElementById("quickModalOverlay");
const closeQuickModalBtn = document.getElementById("closeQuickModalBtn");
const quickModalTitle = document.getElementById("quickModalTitle");
const quickSubmitBtn = document.getElementById("quickSubmitBtn");
const quickActionForm = document.getElementById("quickActionForm");
btnDetailAdd.addEventListener("click", () => {
  quickActionType = "add";
  quickModalTitle.textContent = "Add Amount (+)";
  const p = peopleData.find((x) => x.id === activePersonId);
  quickSubmitBtn.style.backgroundColor = p && p.type === "iowe" ? "#d97706" : "#b91c1c";
  quickModalOverlay.classList.add("active");
});
btnDetailPay.addEventListener("click", () => {
  quickActionType = "pay";
  quickModalTitle.textContent = "Settle / Pay Amount (-)";
  quickSubmitBtn.style.backgroundColor = "#047857";
  quickModalOverlay.classList.add("active");
});
closeQuickModalBtn.addEventListener("click", () => quickModalOverlay.classList.remove("active"));
quickActionForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const numAmount = parseFloat(document.getElementById("quickAmount").value);
  try {
    const data = await api(`/people/${activePersonId}/actions`, {
      method: "POST",
      body: JSON.stringify({ action: quickActionType, amount: numAmount })
    });
    peopleData = data.people || [];
    const p = data.person;
    if (p) {
      detailTotalAmount.textContent = `$ ${p.amount}`;
      renderHistory(p);
    }
    renderPeopleView(peopleTabFilter);
    renderHomeView();
    renderAllTransactionsView();
    updateTotals();
    quickActionForm.reset();
    quickModalOverlay.classList.remove("active");
  } catch (err) {
    alert(err.message);
  }
});

const openModalBtn = document.getElementById("openModalBtn");
const closeModalBtn = document.getElementById("closeModalBtn");
const modalOverlay = document.getElementById("modalOverlay");
const addTransactionForm = document.getElementById("addTransactionForm");
openModalBtn.addEventListener("click", () => modalOverlay.classList.add("active"));
closeModalBtn.addEventListener("click", () => modalOverlay.classList.remove("active"));
addTransactionForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("personName").value;
  const type = document.getElementById("transactionType").value;
  const numAmount = parseFloat(document.getElementById("amount").value);
  try {
    const data = await api("/people", {
      method: "POST",
      body: JSON.stringify({ name, type, amount: numAmount })
    });
    peopleData = data.people || [];
    updateTotals();
    activateNav("people");
    addTransactionForm.reset();
    modalOverlay.classList.remove("active");
  } catch (err) {
    alert(err.message);
  }
});

setLanguage("en");

(async function restoreSession() {
  if (!getToken()) return;
  try {
    const data = await api("/auth/me");
    enterApp(data.user);
  } catch (_err) {
    clearToken();
  }
})();
